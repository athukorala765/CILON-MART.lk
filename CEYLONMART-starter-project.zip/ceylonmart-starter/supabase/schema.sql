-- Run this script in Supabase Dashboard > SQL Editor.
-- Listings are submitted as "pending"; a trusted admin must approve them before publishing.
create extension if not exists pgcrypto;

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 4 and 120),
  category text not null,
  price numeric(14,2) not null check (price >= 0),
  district text not null,
  description text not null default '' check (char_length(description) <= 3000),
  image_url text,
  status text not null default 'pending' check (status in ('pending','published','rejected','sold')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists listings_status_created_idx on public.listings(status, created_at desc);
create index if not exists listings_category_idx on public.listings(category);
create index if not exists listings_district_idx on public.listings(district);
create index if not exists listings_user_id_idx on public.listings(user_id);

alter table public.listings enable row level security;

-- Anyone can view published listings only.
drop policy if exists "Anyone can read published listings" on public.listings;
create policy "Anyone can read published listings"
on public.listings for select
using (status = 'published' or auth.uid() = user_id);

-- Signed-in users may create their own pending listing.
drop policy if exists "Users create own pending listings" on public.listings;
create policy "Users create own pending listings"
on public.listings for insert to authenticated
with check (auth.uid() = user_id and status = 'pending');

-- Owners can update only their own pending/rejected listings. They cannot self-publish.
drop policy if exists "Owners update their unapproved listings" on public.listings;
create policy "Owners update their unapproved listings"
on public.listings for update to authenticated
using (auth.uid() = user_id and status in ('pending','rejected'))
with check (auth.uid() = user_id and status in ('pending','rejected'));

-- Owners may delete their own listings.
drop policy if exists "Owners delete own listings" on public.listings;
create policy "Owners delete own listings"
on public.listings for delete to authenticated
using (auth.uid() = user_id);

-- Storage bucket for listing photos.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('listing-photos', 'listing-photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "Public can view listing photos" on storage.objects;
create policy "Public can view listing photos"
on storage.objects for select
using (bucket_id = 'listing-photos');

drop policy if exists "Users upload photos into own folder" on storage.objects;
create policy "Users upload photos into own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'listing-photos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "Users delete photos from own folder" on storage.objects;
create policy "Users delete photos from own folder"
on storage.objects for delete to authenticated
using (
  bucket_id = 'listing-photos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- IMPORTANT: Do not add a public client-side policy that lets users change status to 'published'.
-- Approve/reject listings only through a protected admin tool or a trusted server-side process.
