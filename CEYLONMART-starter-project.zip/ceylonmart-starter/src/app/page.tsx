"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Listing = {
  id: string;
  title: string;
  category: string;
  price: number;
  district: string;
  description: string | null;
  image_url: string | null;
  created_at: string;
};

const categories = [
  ["📱", "ඉලෙක්ට්‍රොනික භාණ්ඩ"],
  ["🏡", "ඉඩම් හා නිවාස"],
  ["🚗", "වාහන"],
  ["🛋️", "ගෘහ භාණ්ඩ"],
  ["🌿", "කෘෂිකර්ම හා දේශීය නිෂ්පාදන"],
  ["🧰", "සේවා"],
  ["👕", "ඇඳුම් හා විලාසිතා"],
  ["📦", "වෙනත් භාණ්ඩ"],
];

const demoListings: Listing[] = [
  { id: "demo-1", title: "Samsung Galaxy ජංගම දුරකථනය", category: "ඉලෙක්ට්‍රොනික භාණ්ඩ", price: 85000, district: "කොළඹ", description: "උදාහරණ දැන්වීමකි. සැබෑ විකුණුම්කරුගේ තොරතුරු නොවේ.", image_url: null, created_at: new Date().toISOString() },
  { id: "demo-2", title: "පදිංචියට සුදුසු නිවසක්", category: "ඉඩම් හා නිවාස", price: 18500000, district: "ගම්පහ", description: "උදාහරණ දත්ත පමණි. මිලදී ගැනීමට පෙර නීතිමය ලේඛන පරීක්ෂා කරන්න.", image_url: null, created_at: new Date().toISOString() },
  { id: "demo-3", title: "යතුරුපැදියක් විකිණීමට", category: "වාහන", price: 375000, district: "මහනුවර", description: "උදාහරණ දැන්වීමකි. ලියාපදිංචි ලේඛන පරීක්ෂා කරන්න.", image_url: null, created_at: new Date().toISOString() },
  { id: "demo-4", title: "කුරුඳු 100g ඇසුරුම", category: "කෘෂිකර්ම හා දේශීය නිෂ්පාදන", price: 1450, district: "ගාල්ල", description: "උදාහරණ නිෂ්පාදන දැන්වීමකි.", image_url: null, created_at: new Date().toISOString() },
];

export default function HomePage() {
  const [listings, setListings] = useState<Listing[]>(demoListings);
  const [query, setQuery] = useState("");
  const [district, setDistrict] = useState("");
  const [category, setCategory] = useState("");
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [showAuth, setShowAuth] = useState(false);
  const [showPost, setShowPost] = useState(false);
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [postCategory, setPostCategory] = useState("ඉලෙක්ට්‍රොනික භාණ්ඩ");
  const [postDistrict, setPostDistrict] = useState("කොළඹ");
  const [photo, setPhoto] = useState<File | null>(null);

  const supabaseReady = Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);

  async function loadListings() {
    if (!supabaseReady) {
      setLoading(false);
      return;
    }
    try {
      const supabase = createClient();
      const { data, error } = await supabase
        .from("listings")
        .select("id,title,category,price,district,description,image_url,created_at")
        .eq("status", "published")
        .order("created_at", { ascending: false })
        .limit(40);
      if (error) throw error;
      if (data) setListings(data as Listing[]);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "දැන්වීම් ලබාගැනීමට නොහැකි විය.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadListings();
    if (!supabaseReady) return;
    const supabase = createClient();
    void supabase.auth.getUser().then(({ data }) => setUserEmail(data.user?.email ?? ""));
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => setUserEmail(session?.user?.email ?? ""));
    return () => authListener.subscription.unsubscribe();
    // Supabase configuration is read from public environment variables.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => listings.filter((item) => {
    const text = `${item.title} ${item.category} ${item.district} ${item.description ?? ""}`.toLowerCase();
    return (!query || text.includes(query.toLowerCase())) &&
      (!district || item.district === district) &&
      (!category || item.category === category);
  }), [listings, query, district, category]);

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice("");
    if (!supabaseReady) { setNotice("පළමුව Supabase සම්බන්ධ කරන්න. README.md හි පියවර බලන්න."); return; }
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email: authEmail, password: authPassword });
    if (error) setNotice(error.message);
    else { setNotice("පිවිසීම සාර්ථකයි."); setShowAuth(false); }
  }

  async function signUp() {
    setNotice("");
    if (!supabaseReady) { setNotice("පළමුව Supabase සම්බන්ධ කරන්න. README.md හි පියවර බලන්න."); return; }
    const supabase = createClient();
    const { error } = await supabase.auth.signUp({ email: authEmail, password: authPassword });
    if (error) setNotice(error.message);
    else setNotice("ලියාපදිංචි ඉල්ලීම යැවුණා. Supabase email settings පරීක්ෂා කරන්න.");
  }

  async function signOut() {
    if (!supabaseReady) return;
    const { error } = await createClient().auth.signOut();
    setNotice(error?.message ?? "ඔබ ගිණුමෙන් ඉවත් වුණා.");
  }

  async function submitListing(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice("");
    if (!supabaseReady) { setNotice("දැන්වීම් සුරැකීමට පෙර Supabase සම්බන්ධ කරන්න."); return; }
    const supabase = createClient();
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) { setShowPost(false); setShowAuth(true); setNotice("දැන්වීමක් පළ කිරීමට මුලින්ම පිවිසෙන්න."); return; }
    if (!title.trim() || Number(price) < 0 || !price) { setNotice("මාතෘකාව සහ නිවැරදි මිල ඇතුළත් කරන්න."); return; }

    let imageUrl: string | null = null;
    if (photo) {
      const safeName = photo.name.replace(/[^a-zA-Z0-9._-]/g, "-");
      const path = `${auth.user.id}/${crypto.randomUUID()}-${safeName}`;
      const { error: uploadError } = await supabase.storage.from("listing-photos").upload(path, photo, { upsert: false });
      if (uploadError) { setNotice(`ඡායාරූපය උඩුගත කළ නොහැකි විය: ${uploadError.message}`); return; }
      const { data: publicData } = supabase.storage.from("listing-photos").getPublicUrl(path);
      imageUrl = publicData.publicUrl;
    }

    const { error } = await supabase.from("listings").insert({
      user_id: auth.user.id,
      title: title.trim(),
      category: postCategory,
      price: Number(price),
      district: postDistrict,
      description: description.trim(),
      image_url: imageUrl,
      status: "pending",
    });
    if (error) { setNotice(error.message); return; }
    setNotice("දැන්වීම යැවුණා. පරිපාලක අනුමැතියෙන් පසු එය පෙන්වනු ලැබේ.");
    setShowPost(false);
    setTitle(""); setPrice(""); setDescription(""); setPhoto(null);
    await loadListings();
  }

  return (
    <>
      <div className="top"><div className="wrap">🇱🇰 ශ්‍රී ලංකාව පුරා ගැනුම්කරුවන් සහ විකුණුම්කරුවන් එකම තැනක</div></div>
      <header className="header"><div className="wrap header-inner">
        <a className="brand" href="/">CEYLON<span>MART</span></a>
        <div className="actions">
          {userEmail ? <><span className="note">{userEmail}</span><button className="btn" onClick={signOut}>ඉවත් වන්න</button></> : <button className="btn" onClick={() => setShowAuth(!showAuth)}>පිවිසීම / ලියාපදිංචිය</button>}
          <button className="btn primary" onClick={() => setShowPost(!showPost)}>＋ දැන්වීමක් පළ කරන්න</button>
        </div>
      </div></header>

      <main>
        <section className="hero"><div className="wrap"><div className="hero-box">
          <div className="kicker">ශ්‍රී ලංකාවේ අන්තර්ජාල වෙළඳපොළ</div>
          <h1>ඔබට අවශ්‍ය දේ සොයන්න.<br/>ඔබේ භාණ්ඩ විකුණන්න.</h1>
          <p>භාණ්ඩ, ඉඩම්, නිවාස, වාහන සහ සේවා සඳහා දැන්වීම් සොයන්න. ඔබේ දැන්වීම පළ කර ශ්‍රී ලංකාව පුරා සිටින ගැනුම්කරුවන් වෙත ළඟා වන්න.</p>
          <div className="search">
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="භාණ්ඩයක්, නිවසක් හෝ ඉඩමක් සොයන්න..." aria-label="සෙවීම" />
            <select value={district} onChange={(e) => setDistrict(e.target.value)} aria-label="දිස්ත්‍රික්කය">
              <option value="">සියලු දිස්ත්‍රික්ක</option>
              {["කොළඹ","ගම්පහ","කළුතර","මහනුවර","ගාල්ල","මාතර","කුරුණෑගල","යාපනය","අනුරාධපුර","බදුල්ල","මඩකලපුව","ත්‍රිකුණාමලය"].map((d) => <option key={d}>{d}</option>)}
            </select>
            <button className="btn primary" onClick={() => document.getElementById("listings")?.scrollIntoView({ behavior: "smooth" })}>සොයන්න</button>
          </div>
        </div></div></section>

        <section className="section"><div className="wrap">
          <div className="section-head"><div><h2>වර්ග අනුව සොයන්න</h2><p>ඔබට අවශ්‍ය වෙළඳ දැන්වීම් වර්ගය තෝරන්න.</p></div></div>
          <div className="categories">
            {categories.map(([emoji, label]) => <button className="category" key={label} onClick={() => { setCategory(category === label ? "" : label); document.getElementById("listings")?.scrollIntoView({ behavior: "smooth" }); }}><span className="emoji">{emoji}</span><strong>{label}</strong></button>)}
          </div>
        </div></section>

        {showAuth && <section className="section"><div className="wrap"><div className="card card-body">
          <div className="section-head"><div><h2>ගිණුමට පිවිසෙන්න</h2><p>ගිණුමක් නොමැති නම් ලියාපදිංචි වන්න.</p></div><button className="btn" onClick={() => setShowAuth(false)}>වසන්න</button></div>
          <form onSubmit={signIn} style={{ display: "grid", gap: 10, maxWidth: 460 }}>
            <label>ඊමේල් ලිපිනය<input type="email" required value={authEmail} onChange={(e) => setAuthEmail(e.target.value)} /></label>
            <label>මුරපදය<input type="password" required minLength={6} value={authPassword} onChange={(e) => setAuthPassword(e.target.value)} /></label>
            <div className="actions"><button className="btn primary" type="submit">පිවිසෙන්න</button><button className="btn" type="button" onClick={signUp}>නව ගිණුමක් සාදන්න</button></div>
          </form>
        </div></div></section>}

        {showPost && <section className="section"><div className="wrap"><div className="card card-body">
          <div className="section-head"><div><h2>නව දැන්වීමක්</h2><p>දැන්වීම පළ කිරීමට පරිශීලක ගිණුමකින් පිවිසිය යුතුය.</p></div><button className="btn" onClick={() => setShowPost(false)}>වසන්න</button></div>
          <form onSubmit={submitListing} style={{ display: "grid", gap: 12, maxWidth: 700 }}>
            <label>දැන්වීමේ මාතෘකාව<input required maxLength={120} value={title} onChange={(e) => setTitle(e.target.value)} /></label>
            <label>වර්ගය<select value={postCategory} onChange={(e) => setPostCategory(e.target.value)}>{categories.map(([, label]) => <option key={label}>{label}</option>)}</select></label>
            <label>මිල (LKR)<input type="number" required min="0" value={price} onChange={(e) => setPrice(e.target.value)} /></label>
            <label>දිස්ත්‍රික්කය<select value={postDistrict} onChange={(e) => setPostDistrict(e.target.value)}>{["කොළඹ","ගම්පහ","කළුතර","මහනුවර","ගාල්ල","මාතර","කුරුණෑගල","යාපනය","අනුරාධපුර","බදුල්ල","මඩකලපුව","ත්‍රිකුණාමලය","වෙනත්"].map((d) => <option key={d}>{d}</option>)}</select></label>
            <label>විස්තර<textarea maxLength={3000} value={description} onChange={(e) => setDescription(e.target.value)} rows={4} /></label>
            <label>ඡායාරූපය<input type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => setPhoto(e.target.files?.[0] ?? null)} /></label>
            <button className="btn primary" type="submit">දැන්වීම යවන්න</button>
          </form>
        </div></div></section>}

        <section className="section" id="listings"><div className="wrap">
          <div className="section-head"><div><h2>අලුත් දැන්වීම්</h2><p>{loading ? "දැන්වීම් ලබාගනිමින්..." : `${filtered.length} දැන්වීම්`}</p></div><select aria-label="වර්ගය අනුව පෙරීම" value={category} onChange={(e) => setCategory(e.target.value)} style={{ maxWidth: 270 }}><option value="">සියලු වර්ග</option>{categories.map(([, label]) => <option key={label}>{label}</option>)}</select></div>
          {notice && <p className="notice" role="status">{notice}</p>}
          {!supabaseReady && <p className="notice">දැනට demo දැන්වීම් පෙන්වයි. සැබෑ ගිණුම්, දැන්වීම් සහ ඡායාරූප සඳහා README.md හි Supabase setup පියවර සම්පූර්ණ කරන්න.</p>}
          <div className="grid">
            {filtered.map((item) => <article className="card" key={item.id}>
              <div className="card-img">{item.image_url ? <img src={item.image_url} alt={item.title} style={{ width: "100%", height: 150, objectFit: "cover" }} /> : (item.category.includes("නිවාස") ? "🏡" : item.category.includes("වාහන") ? "🚗" : item.category.includes("කුරුඳු") ? "🌿" : "📦")}</div>
              <div className="card-body"><span className="badge">{item.category}</span><h3>{item.title}</h3><div className="price">LKR {Number(item.price).toLocaleString("en-LK")}</div><div className="meta">📍 {item.district}</div><p className="note">{item.description || "වැඩි විස්තර සඳහා විකුණුම්කරු අමතන්න."}</p></div>
            </article>)}
          </div>
          {!loading && filtered.length === 0 && <p className="notice">ගැළපෙන දැන්වීම් හමු නොවීය. වෙනත් සෙවුමක් උත්සාහ කරන්න.</p>}
        </div></section>
      </main>
      <footer className="footer"><div className="wrap"><a className="brand" href="/" style={{ color: "white" }}>CEYLON<span style={{ color: "#b7e9d5" }}>MART</span></a><p>ශ්‍රී ලංකාවේ භාණ්ඩ, ඉඩම්, නිවාස සහ වාහන මිලදී ගැනීමට සහ විකිණීමට දැන්වීම් වෙළඳපොළක්.</p><p>ආරක්ෂාව: මුදල් ගෙවීමට පෙර භාණ්ඩ පරීක්ෂා කරන්න. ඉඩම් හා නිවාස සඳහා හිමිකම් ලේඛන සුදුසු වෘත්තිකයෙකු සමඟ පරීක්ෂා කරන්න.</p><small>© {new Date().getFullYear()} CEYLONMART · ආදර්ශ ව්‍යාපෘතිය</small></div></footer>
    </>
  );
}
