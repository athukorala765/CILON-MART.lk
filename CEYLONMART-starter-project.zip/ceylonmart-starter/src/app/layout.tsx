import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CEYLONMART — ශ්‍රී ලංකාවේ වෙළඳපොළ",
  description: "භාණ්ඩ, ඉඩම්, නිවාස, වාහන සහ සේවා මිලදී ගන්න සහ විකුණන්න.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="si">
      <body>{children}</body>
    </html>
  );
}
