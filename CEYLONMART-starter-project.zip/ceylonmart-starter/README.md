# CEYLONMART — Starter Project

මෙය CEYLONMART සඳහා Next.js + Supabase starter project එකකි. මෙහි Sinhala-first homepage, category/search filters, email/password sign-in and sign-up, listing submission, photo upload, and pending moderation status ඇතුළත්ය.

**මෙය තවම සම්පූර්ණ production marketplace එකක් නොවේ.** Admin dashboard, seller dashboard, messaging, reporting, Tamil/English translations, phone OTP, payments, legal policies and production security review තවම එකතු කළ යුතුය.

## 1. ඔබට අවශ්‍ය දේ
- GitHub account
- Supabase account
- Node.js LTS ඔබගේ පරිගණකයේ
- Netlify හෝ Vercel account (deployment සඳහා)

## 2. ව්‍යාපෘතිය පරිගණකයේ ධාවනය කරන්න
1. ZIP එක extract කරන්න.
2. Node.js LTS ස්ථාපනය කරන්න: https://nodejs.org/
3. project folder එකේ Terminal / Command Prompt එක විවෘත කරන්න.
4. මෙය ධාවනය කරන්න:

   ```bash
   npm install
   ```

5. `.env.example` ගොනුව copy කර `.env.local` නමින් save කරන්න.
6. Supabase project එකෙන් Project URL සහ publishable/anon key ලබාගෙන `.env.local` තුළ පුරවන්න. `service_role` key එක කිසිවිටක browser/frontend code එකට දාන්න එපා.
7. මෙය ධාවනය කරන්න:

   ```bash
   npm run dev
   ```

8. browser එකෙන් http://localhost:3000 විවෘත කරන්න.

## 3. Supabase සකස් කරන්න
1. https://supabase.com/ වෙත ගොස් project එකක් සාදන්න.
2. Dashboard > SQL Editor > New query විවෘත කරන්න.
3. `supabase/schema.sql` ගොනුවේ සම්පූර්ණ SQL code එක paste කර Run කරන්න.
4. Project Settings > API (හෝ API Keys) වෙතින් Project URL සහ publishable/anon key ලබාගන්න.
5. ඒවා `.env.local` තුළ දමන්න. උදාහරණය:

   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-public-anon-key
   ```

6. Authentication > Providers තුළ Email provider සක්‍රීය බව තහවුරු කරන්න.
7. Authentication > URL Configuration තුළ local URL `http://localhost:3000` එක redirect/site URL ලෙස development සඳහා සකසන්න.
8. App එක නැවත ආරම්භ කරන්න (`Ctrl+C`, පසුව `npm run dev`).

## 4. දැන්වීම් ක්‍රියාවලිය
- නරඹන්නන්ට `published` දැන්වීම් පමණක් පෙන්වයි.
- ලියාපදිංචි වූ පරිශීලකයෙකුගේ දැන්වීම `pending` තත්ත්වයෙන් සුරැකේ.
- පරිශීලකයාට තමන්ගේ pending listing එක ස්වයංක්‍රීයව publish කළ නොහැකි ලෙස Row Level Security (RLS) යොදා ඇත.
- පරිපාලක අනුමත කිරීම සඳහා ආරක්ෂිත admin dashboard/server-side process එකක් තවම build කළ යුතුය.
- ඡායාරූප 5 MB දක්වා JPEG/PNG/WebP ලෙස සීමා කර ඇත.

## 5. Hosting
Netlify හෝ Vercel එකේ GitHub repository එක import කරන්න. Build command `npm run build`, output settings Next.js default ලෙස තබන්න. Hosting dashboard එකේ Environment Variables තුළ `NEXT_PUBLIC_SUPABASE_URL` සහ `NEXT_PUBLIC_SUPABASE_ANON_KEY` add කරන්න. Deploy කිරීමෙන් පසු Supabase Authentication URL Configuration එකට ඔබගේ production URL එකත් add කරන්න.

Free plan limits වෙනස් විය හැකි බැවින් deploy කිරීමට පෙර provider pricing/limits පරීක්ෂා කරන්න.

## 6. Production කිරීමට පෙර අනිවාර්ය වැඩ
- Admin dashboard + admin authorization (server-side, database-backed role check)
- Seller dashboard: own listings, edit/delete, status tracking
- Secure messaging/enquiries (database + RLS)
- Listing report/flagging and moderation queue
- Image upload UX: preview, compression, file validation
- Sinhala / Tamil / English translations
- More complete Sri Lankan district and category data
- Privacy policy, terms, prohibited listings and reporting contact
- Rate limiting, spam protection, abuse monitoring and backups
- Accessibility, SEO, mobile testing, error handling and security review
- If paid listings are added, integrate a supported payment provider only after server-side verification

## 7. Security reminders
- Never put Supabase `service_role` secret in frontend or `NEXT_PUBLIC_` variables.
- Keep RLS enabled. Never allow ordinary users to set `status = 'published'`.
- Do not mark a seller as verified without a real verification process.
- This is a classifieds platform: buyers and sellers arrange transactions directly. Do not claim payments or escrow are supported unless implemented and tested.
